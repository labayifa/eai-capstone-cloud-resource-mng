# dmc theme
This app allows you to easily see how default Dash Mantine components behave when you switch between different themes.

# google-auth-flask-session
